---
name: ❓ Question
about: Ask a question about this project 🎓
title: ''
labels: question
assignees:
---

## Checklist

<!-- Mark with an `x` all the checkboxes that apply (like `[x]`). -->

<!-- Regardless, if something isn't clearly documented or easy to understand - let me know! -->

- [ ] I've searched the project's [`issues`](https://github.com/pglombardo/PasswordPusher/issues?q=is%3Aissue).
- [ ] I've searched the project's [`discussions`](https://github.com/pglombardo/PasswordPusher/discussions).

## ❓ Question

<!-- What is your question -->

How can I [...]?

Is it possible to [...]?

## 📎 Additional context

<!-- Add any other context or screenshots about the feature request here. -->
