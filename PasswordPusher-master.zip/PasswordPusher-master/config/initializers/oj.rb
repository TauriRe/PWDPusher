# frozen_string_literal: true

Oj.default_options = { mode: :rails }
Oj.optimize_rails
