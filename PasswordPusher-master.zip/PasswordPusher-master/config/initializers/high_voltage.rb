# frozen_string_literal: true

HighVoltage.configure do |config|
  config.routes = false
end
