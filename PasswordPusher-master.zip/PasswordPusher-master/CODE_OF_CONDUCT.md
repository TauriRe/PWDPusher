"Never Be Cruel. Never Be Cowardly. Hate Is Always Foolish. Love Is Always Wise. Always Try To Be Nice, But Never Fail To Be Kind."
  - Doctor Who
